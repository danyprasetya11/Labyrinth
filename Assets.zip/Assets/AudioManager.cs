using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class AudioManager : MonoBehaviour
{
    static AudioSource bgmInstance;
    static AudioSource sfxInstance;
    // static AudioSource holeWinInstance;
    // static AudioSource holeLoseInstance;
    [SerializeField] AudioSource bgm;
    [SerializeField] AudioSource sfx;
    [SerializeField] AudioSource holeLose;
    [SerializeField] AudioSource holeWin;
    // [SerializeField] AudioSource belfry;
    // [SerializeField] AudioSource birds;

    #region  Save Key
    private string bgmSaveKey = "bgmSave";
    private string sfxSaveKey = "sfxSave";
    #endregion
    

    public bool IsMute { get => bgm.mute; }
    public float BgmVolume { get => bgm.volume; }
    public float SfxVolume { get => sfx.volume; }



    private void Start()
    {

        bgm.volume = PlayerPrefs.GetFloat(bgmSaveKey);
        // belfry.volume = PlayerPrefs.GetFloat(bgmSaveKey);
        // birds.volume = PlayerPrefs.GetFloat(bgmSaveKey);
        sfx.volume = PlayerPrefs.GetFloat(sfxSaveKey);
        // confettiSound.volume = PlayerPrefs.GetFloat(sfxSaveKey);
        
        
        
        if(bgmInstance != null) 
        {
            Destroy(this.bgm.gameObject);  
            bgm = bgmInstance;  
        }
        else
        {
            bgmInstance = bgm;   
            bgm.transform.SetParent(null);
            DontDestroyOnLoad(bgm.gameObject);  
        }

        if(sfxInstance != null)
        {
            Destroy(this.sfx.gameObject);
            sfx = sfxInstance;
        }
        else
        {
            sfxInstance = sfx;
            sfx.transform.SetParent(null);
            DontDestroyOnLoad(sfx.gameObject);
        }
        
        // if(holeLoseInstance != null)
        // {
        //     Destroy(this.holeLose.gameObject);
        //     holeLose = holeLoseInstance;
        // }
        // else
        // {
        //     holeLoseInstance = holeLose;
        //     holeLose.transform.SetParent(null);
        //     DontDestroyOnLoad(holeLose.gameObject);
        // }

        // if(holeWinInstance != null)
        // {
        //     Destroy(this.holeWin.gameObject);
        //     holeWin = holeWinInstance;
        // }
        // else
        // {
        //     holeWinInstance = holeWin;
        //     holeWin.transform.SetParent(null);
        //     DontDestroyOnLoad(holeWin.gameObject);
        // }
        
    }

    private void Update()
    {
        holeLose.volume = sfx.volume;
        holeWin.volume = sfx.volume;
        holeLose.mute = bgm.mute;
        holeWin.mute = bgm.mute;
    }

    public void playBGM(AudioClip clip, bool loop =true)
    {
        if(bgm.isPlaying)
            bgm.Stop();

        bgm.clip = clip;
        bgm.loop = loop;
        bgm.Play();
    }

    public void PlaySFX(AudioClip clip)
    {
        if(sfx.isPlaying)
            sfx.Stop();  

        sfx.clip = clip;
        sfx.Play();
    }


    public void SetMute(bool value)
    {
        

        bgm.mute = value;
        sfx.mute = value;
        holeLose.mute = value;
        holeWin.mute = value;
       
        // belfry.mute = value;
        // birds.mute = value;

        
        
    }

    public void SetBgmVolume(float value)
    {
        bgm.volume = value;

        PlayerPrefs.SetFloat(bgmSaveKey, value);
    }
    

    public void SetSfxVolume(float value)
    {
        sfx.volume = value;
        holeLose.volume = value;
        holeWin.volume = value;

        PlayerPrefs.SetFloat(sfxSaveKey, value);
        
    }

    // public void SetBirdsVolumeOff()
    // {
    //     birds.gameObject.SetActive(false);
        
    // }

    // public void SetBirdsVolumeOn()
    // {
    //     birds.gameObject.SetActive(true);
        
    // }
}
