using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Ball : MonoBehaviour
{

[SerializeField] CustomEvent customEvent;
public UnityEvent <int> OnGetCoin;
public UnityEvent OnDie;
public UnityEvent OnCube;
GravityController gravityController;

private void OnTriggerEnter(Collider other)
    {

        if(other.CompareTag("Coin"))
        {
            var coin = other.GetComponent<Coin>();
            OnGetCoin.Invoke(coin.Value);
            coin.Collected();
        }


    }

private void OnTriggerStay(Collider other)
{
    if(other.CompareTag("Cube"))
        {
            Debug.Log("execute");
            // gravityController.SetActive(false);
            OnCube.Invoke();
            Invoke("Die",3);
   
        }
}

     private void Die()
    {
        OnDie.Invoke();
        customEvent.OnInvoked.Invoke();
    }
}
