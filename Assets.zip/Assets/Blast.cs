using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Blast : MonoBehaviour
{
    [SerializeField] Cube cube;
    [SerializeField] Ball ball;
    [SerializeField] float initialTimer = 20;

    GravityController gravityController;
    public UnityEvent <float> OnTimerUpdate;


 

    float timer;
    bool cubeActive = true;
    void Start()
    {
        timer = initialTimer;
        cube.gameObject.SetActive(false);
    }

    void Update()
    {
        if(timer <= 0 && cubeActive == true)
        {
            cube.gameObject.SetActive(true);
            cube.transform.position = ball.transform.position;
        
            cubeActive = false;
        }

        if(timer >= 0 && cubeActive == true)
            OnTimerUpdate.Invoke(timer);

        timer -=Time.deltaTime;
   
;
    }


}
