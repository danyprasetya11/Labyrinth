using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    [SerializeField] Camera cam;
    float frustumScale;

    private void Start()
    {
        var camDistance = cam.transform.position.y;
        var frustumHight = 2 * camDistance * Mathf.Tan(cam.fieldOfView * 0.5f * Mathf.Deg2Rad);
        frustumScale = frustumHight/ Screen.height;
    }

    void Update()
    {
        var touches = Input.touches;

        switch (touches.Length)
        {
            case 1:
                Drag(touches);
                break;
            case 2:
                Zoom(touches);
                break;   
        }      
    }

    private void Drag(Touch[] touches)
    {
        var touch = Input.GetTouch(0);
        
       
        //jika menggeser ke kanan, posisi kamera akan -= camera.pos.x sehingga layar bergeser ke kanan.
        cam.transform.position -= new Vector3(touch.deltaPosition.x,0,touch.deltaPosition.y) * frustumScale;
    }

    private void Zoom(Touch[] touches)
    {
        var prevPos0 = touches[0].position - touches[0].deltaPosition;
        var prevPos1 = touches[1].position - touches[1].deltaPosition;
        var prevDistance = Vector2.Distance(prevPos0, prevPos1);
        var currentDistance = Vector2.Distance(touches[0].position, touches[1].position);
        var deltaDistance = currentDistance - prevDistance;

        if(cam.orthographic)
        {
            cam.orthographicSize -= deltaDistance * 0.01f ;
            cam.orthographicSize = Mathf.Clamp(cam.orthographicSize, 2, 15);
        }
        else
        {
            var camDistance = cam.transform.position.y;
            var frustumHight = 2 * camDistance * Mathf.Tan(cam.fieldOfView * 0.5f * Mathf.Deg2Rad);
            frustumScale = frustumHight/ Screen.height;


            // -= kalau ke kanan, kamera ke kiri
            cam.transform.position -= Vector3.up * deltaDistance * 0.1f;
            var y = Mathf.Clamp(cam.transform.position.y, 10, 100);
            cam.transform.position = new Vector3(cam.transform.position.x, y, cam.transform.position.z);
        }
    } 
}
