using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Hole : MonoBehaviour
{
    [SerializeField] CustomEvent customEvent;
    [SerializeField] AudioSource hole;
    public UnityEvent cubeDeactive;
    private void OnCollisionEnter(Collision other)
    {
        OnTriggerEnter(other.collider);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Ball"))
        {
            cubeDeactive.Invoke();
            hole.Play();
            customEvent.OnInvoked.Invoke();
        }

    }
}
