using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
using UnityEngine.Events;

public class Obstacle : MonoBehaviour
{
    [SerializeField] float duration = 1;
    [SerializeField] List <Transform> positions;
    public UnityEvent laser;


    int index;
    private void Start()
    {
        Move();
    }

    private void Move()
    {
        var pos = positions[index];
        this.transform
            .DOMove(pos.position,duration)
            .onComplete = Move;

        index += 1;
        if(index == positions.Count)
            index = 0;

        if(index == 32)
            laser.Invoke();
            
    
    }

    public void LaserSound()
    {
        Destroy(this.gameObject);
    }
}
