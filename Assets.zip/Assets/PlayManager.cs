using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using UnityEngine.Events;

public class PlayManager : MonoBehaviour
{
    [SerializeField] GameObject FinishedCanvas;
    [SerializeField] TMP_Text finishedText; 
    [SerializeField] CustomEvent gameOverEvent;
    [SerializeField] CustomEvent playerWinEvent;
    [SerializeField] GameObject optionsWindow;

    public UnityEvent <int> OnScoreUpdate;
    public UnityEvent OnGameStart;

    int coin;

    private void Start()
    {
        OnGameStart.Invoke();
    }

    private void OnEnable()
    {
        gameOverEvent.OnInvoked.AddListener(GameOver);
        playerWinEvent.OnInvoked.AddListener(PlayerWin);
    }

    private void OnDisable()
    {
        gameOverEvent.OnInvoked.RemoveListener(GameOver);
        playerWinEvent.OnInvoked.RemoveListener(PlayerWin);
    }
    public void GameOver()
    {
       finishedText.text = "You Failed\nScore: " + GetScore();
       FinishedCanvas.SetActive(true);
    }

    public void PlayerWin()
    {
        finishedText.text = "You Win\nScore: " + GetScore();
        FinishedCanvas.SetActive(true);
    }

    private int GetScore()
    {
        return coin * 10;
    }

    public void AddCoin(int value)
    {
        this.coin += value;
        OnScoreUpdate.Invoke(GetScore());
    }

    

        public void Replay()
    {  
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void Quit()
    {
        SceneManager.LoadScene("Main");
    }

    public void Options()
    {
        if(Input.GetKeyDown(KeyCode.Escape))
            optionsWindow.SetActive(true);
        
    }
}
