using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class StartCountDown: MonoBehaviour
{
    [SerializeField] TMP_Text text;

    public void UpdateWaitText(int value)
    {
        text.text = value.ToString();
    }
}
