using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class TimerText : MonoBehaviour
{
   [SerializeField] TMP_Text timerText;
    


    public void UpdateTime(float timer)
    {
        timer = Mathf.Floor(timer);
        timerText.text ="Timer: " + timer.ToString();

    }
}
